import { useAuth } from '../store/AuthContext';
import { Globe, BookOpen, Scan, Film, CreditCard, School, Star, ArrowRight, Crown, Sparkles, Rocket, CheckCircle, Users, Zap } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const { isLoggedIn, isPremium } = useAuth();

  const features = [
    { icon: Scan, title: 'WebAR Interaktif', desc: 'Scan kartu dan lihat konten 3D muncul!', color: 'from-purple-500 to-indigo-600', page: 'scanner' },
    { icon: Globe, title: '3D Globe 4K', desc: 'Jelajahi dunia dengan globe interaktif!', color: 'from-blue-500 to-cyan-600', page: 'globe' },
    { icon: BookOpen, title: '9 Modul Belajar', desc: 'Matematika, Sains, Bahasa, dan lainnya!', color: 'from-green-500 to-emerald-600', page: 'modules' },
    { icon: Film, title: 'Film Edukasi', desc: 'Petualangan Aksa & Globe Ajaib!', color: 'from-rose-500 to-pink-600', page: 'films' },
    { icon: CreditCard, title: 'Kartu Premium', desc: 'Aktivasi kode untuk fitur lengkap!', color: 'from-amber-500 to-orange-600', page: 'license' },
    { icon: School, title: 'Lisensi Sekolah', desc: 'Paket SaaS untuk institusi pendidikan!', color: 'from-teal-500 to-emerald-600', page: 'school' },
  ];

  const stats = [
    { value: '9+', label: 'Modul Belajar' },
    { value: '12+', label: 'Negara di Globe' },
    { value: '50+', label: 'Kuis Interaktif' },
    { value: '100%', label: 'Offline Ready' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900 text-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500/20 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-500/10 rounded-full blur-3xl"></div>
          {/* Floating particles */}
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white/30 rounded-full"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 3}s`
              }}
            />
          ))}
        </div>

        <div className="relative max-w-7xl mx-auto px-4 py-20 md:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8 animate-slide-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur rounded-full text-sm">
                <Sparkles className="w-4 h-4 text-yellow-400" />
                Platform EdTech #1 Indonesia
              </div>
              <h1 className="text-4xl md:text-6xl font-extrabold leading-tight">
                <span className="bg-gradient-to-r from-blue-300 via-cyan-300 to-purple-300 bg-clip-text text-transparent">
                  EduCard World
                </span>
                <br />
                <span className="text-white/90 text-3xl md:text-5xl">Belajar Jadi Petualangan!</span>
              </h1>
              <p className="text-lg text-blue-200/80 max-w-xl leading-relaxed">
                Platform pembelajaran interaktif dengan WebAR, 3D Globe, Film Edukasi, dan 9+ modul belajar yang dirancang khusus untuk anak-anak Indonesia.
              </p>
              <div className="flex flex-wrap gap-4">
                <button
                  onClick={() => onNavigate(isLoggedIn ? 'modules' : 'login')}
                  className="group flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl font-semibold text-lg hover:shadow-2xl hover:shadow-blue-500/25 transition-all cursor-pointer"
                >
                  <Rocket className="w-5 h-5" />
                  Mulai Belajar
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
                <button
                  onClick={() => onNavigate('globe')}
                  className="flex items-center gap-2 px-8 py-4 bg-white/10 backdrop-blur rounded-xl font-semibold text-lg hover:bg-white/20 transition-all border border-white/20 cursor-pointer"
                >
                  <Globe className="w-5 h-5" />
                  Jelajahi Globe
                </button>
              </div>
              {/* Stats */}
              <div className="grid grid-cols-4 gap-4 pt-4">
                {stats.map(stat => (
                  <div key={stat.label} className="text-center">
                    <div className="text-2xl md:text-3xl font-bold text-white">{stat.value}</div>
                    <div className="text-xs text-blue-300/70 mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero visual */}
            <div className="hidden lg:flex justify-center">
              <div className="relative">
                <div className="w-80 h-80 rounded-full bg-gradient-to-br from-blue-400/30 to-purple-500/30 backdrop-blur-xl border border-white/10 flex items-center justify-center animate-float">
                  <div className="text-center space-y-4">
                    <div className="text-8xl">🌍</div>
                    <div className="text-xl font-bold">Jelajahi Dunia</div>
                    <div className="text-sm text-blue-200/70">WebAR + 3D + Film</div>
                  </div>
                </div>
                {/* Orbiting elements */}
                <div className="absolute -top-4 -right-4 w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center text-2xl shadow-xl animate-float" style={{ animationDelay: '0.5s' }}>📚</div>
                <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-to-br from-green-400 to-emerald-500 rounded-2xl flex items-center justify-center text-2xl shadow-xl animate-float" style={{ animationDelay: '1s' }}>🔬</div>
                <div className="absolute top-1/2 -right-8 w-14 h-14 bg-gradient-to-br from-pink-400 to-rose-500 rounded-2xl flex items-center justify-center text-2xl shadow-xl animate-float" style={{ animationDelay: '1.5s' }}>🎨</div>
                <div className="absolute top-0 left-1/4 w-14 h-14 bg-gradient-to-br from-purple-400 to-indigo-500 rounded-2xl flex items-center justify-center text-2xl shadow-xl animate-float" style={{ animationDelay: '2s' }}>🎬</div>
              </div>
            </div>
          </div>
        </div>

        {/* Wave */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 100" fill="none" className="w-full"><path d="M0,60 C360,100 1080,0 1440,60 L1440,100 L0,100 Z" fill="white"/></svg>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-full text-sm font-medium mb-4">
              <Star className="w-4 h-4" /> Fitur Unggulan
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Semua Yang Kamu Butuhkan</h2>
            <p className="text-gray-500 max-w-2xl mx-auto">Platform lengkap untuk belajar dengan cara yang menyenangkan dan interaktif</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <button
                  key={i}
                  onClick={() => onNavigate(feature.page)}
                  className="group p-6 bg-white rounded-2xl border border-gray-100 hover:border-blue-200 hover:shadow-xl transition-all duration-300 text-left cursor-pointer"
                >
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{feature.desc}</p>
                  <div className="flex items-center gap-1 mt-4 text-blue-600 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                    Jelajahi <ArrowRight className="w-4 h-4" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Premium CTA */}
      {!isPremium && (
        <section className="py-20 bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50">
          <div className="max-w-5xl mx-auto px-4">
            <div className="bg-gradient-to-br from-amber-400 via-yellow-400 to-orange-400 rounded-3xl p-8 md:p-12 text-center relative overflow-hidden shadow-2xl">
              <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTAiIGN5PSIxMCIgcj0iMSIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjIpIi8+PC9zdmc+')] opacity-50"></div>
              <div className="relative">
                <Crown className="w-16 h-16 text-white/90 mx-auto mb-6" />
                <h2 className="text-3xl md:text-4xl font-extrabold text-white mb-4">Upgrade ke Premium!</h2>
                <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
                  Dapatkan akses ke semua modul, 3D Globe 4K, film edukasi lengkap, dan fitur AR tanpa batas!
                </p>
                <div className="flex flex-wrap justify-center gap-4 mb-8">
                  {['4K Globe Detail', 'Semua 9 Modul', 'Film 5 Menit', 'AR Tanpa Batas', 'Offline Mode'].map(f => (
                    <span key={f} className="flex items-center gap-1 px-3 py-1.5 bg-white/20 backdrop-blur rounded-full text-white text-sm">
                      <CheckCircle className="w-4 h-4" /> {f}
                    </span>
                  ))}
                </div>
                <button
                  onClick={() => onNavigate('license')}
                  className="px-8 py-4 bg-white text-amber-600 font-bold text-lg rounded-xl hover:shadow-xl transition-all cursor-pointer"
                >
                  Aktivasi Kode Premium
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Business Model */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Model Bisnis</h2>
            <p className="text-gray-500">Berbagai paket untuk kebutuhan berbeda</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: 'Basic', price: 'Gratis', features: ['5 Modul Dasar', 'Preview Globe', 'Preview Film 1 Menit', '3 AR Marker'], color: 'from-gray-500 to-gray-600', icon: Zap },
              { name: 'Premium', price: 'Rp 99.000', features: ['Semua 9 Modul', '4K Globe Lengkap', 'Film 5 Menit', 'Semua AR Marker', 'Offline Mode'], color: 'from-blue-500 to-indigo-600', icon: Crown, popular: true },
              { name: 'Sekolah', price: 'Rp 499.000/thn', features: ['Max 100 Siswa', 'Dashboard Admin', 'Laporan Progress', 'Dukungan Prioritas', 'Custom Branding'], color: 'from-emerald-500 to-teal-600', icon: Users },
            ].map(plan => {
              const Icon = plan.icon;
              return (
                <div key={plan.name} className={`relative bg-white rounded-2xl p-8 shadow-lg border-2 ${plan.popular ? 'border-blue-500 scale-105' : 'border-transparent'} hover:shadow-xl transition-all`}>
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-blue-500 to-indigo-500 text-white text-sm font-bold rounded-full">
                      POPULER
                    </div>
                  )}
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-6`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{plan.name}</h3>
                  <div className="text-3xl font-extrabold text-gray-900 mt-2 mb-6">{plan.price}</div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map(f => (
                      <li key={f} className="flex items-center gap-2 text-gray-600 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 shrink-0" /> {f}
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={() => onNavigate(plan.name === 'Sekolah' ? 'school' : 'license')}
                    className={`w-full py-3 rounded-xl font-semibold transition-all cursor-pointer ${
                      plan.popular
                        ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white hover:shadow-lg'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {plan.name === 'Basic' ? 'Mulai Gratis' : 'Pilih Paket'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <span className="font-bold text-lg">EduCard World</span>
              </div>
              <p className="text-gray-400 text-sm">Platform EdTech berbasis WebAR, 3D Globe, dan Modular Learning untuk anak Indonesia.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Produk</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><button onClick={() => onNavigate('modules')} className="hover:text-white cursor-pointer">Modul Belajar</button></li>
                <li><button onClick={() => onNavigate('globe')} className="hover:text-white cursor-pointer">3D Globe</button></li>
                <li><button onClick={() => onNavigate('scanner')} className="hover:text-white cursor-pointer">WebAR Scanner</button></li>
                <li><button onClick={() => onNavigate('films')} className="hover:text-white cursor-pointer">Film Edukasi</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Bisnis</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><button onClick={() => onNavigate('license')} className="hover:text-white cursor-pointer">Aktivasi Premium</button></li>
                <li><button onClick={() => onNavigate('school')} className="hover:text-white cursor-pointer">Lisensi Sekolah</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Teknologi</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>React + TypeScript</li>
                <li>Three.js 3D</li>
                <li>MindAR + A-Frame</li>
                <li>PWA Offline</li>
                <li>MongoDB Backend</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-6 text-center text-gray-500 text-sm">
            © 2024 EduCard World. All rights reserved. Platform EdTech berbasis WebAR + SaaS.
          </div>
        </div>
      </footer>
    </div>
  );
}
