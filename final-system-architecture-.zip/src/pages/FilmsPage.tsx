import { useState } from 'react';
import { useAuth } from '../store/AuthContext';
import { filmScript } from '../data/modules';
import { Film, Play, Lock, Crown, Clock, ChevronDown, ChevronUp, BookOpen, Pause } from 'lucide-react';

interface FilmsPageProps {
  onNavigate: (page: string) => void;
}

export function FilmsPage({ onNavigate }: FilmsPageProps) {
  const { isPremium } = useAuth();
  const [showScript, setShowScript] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [currentScene, setCurrentScene] = useState(0);
  const [progress, setProgress] = useState(0);

  const startPlaying = () => {
    setPlaying(true);
    setCurrentScene(0);
    setProgress(0);
    
    // Simulate video playback
    const maxScene = isPremium ? filmScript.scenes.length : 2; // Basic: only first 2 scenes (1 minute)
    let p = 0;
    const interval = setInterval(() => {
      p += 0.5;
      const maxProgress = isPremium ? 100 : 20; // Basic: 20% (1 minute of 5)
      if (p >= maxProgress) {
        clearInterval(interval);
        if (!isPremium) {
          setPlaying(false);
        }
      }
      setProgress(Math.min(p, maxProgress));
      const sceneIdx = Math.min(Math.floor((p / 100) * filmScript.scenes.length), maxScene - 1);
      setCurrentScene(sceneIdx);
    }, 150);

    return () => clearInterval(interval);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Film className="w-8 h-8 text-rose-600" />
            Film Edukasi
          </h1>
          <p className="text-gray-500 mt-2">Film animasi pendidikan untuk anak-anak</p>
        </div>

        {/* Main Film Card */}
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden mb-8">
          {/* Video Player Area */}
          <div className="relative aspect-video bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center overflow-hidden">
            {/* Background animation */}
            <div className="absolute inset-0">
              {Array.from({ length: 30 }).map((_, i) => (
                <div
                  key={i}
                  className="absolute rounded-full"
                  style={{
                    width: Math.random() * 4 + 1 + 'px',
                    height: Math.random() * 4 + 1 + 'px',
                    background: `rgba(255,255,255,${Math.random() * 0.3})`,
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                    animation: `float ${3 + Math.random() * 5}s ease-in-out infinite`,
                    animationDelay: `${Math.random() * 3}s`,
                  }}
                />
              ))}
            </div>

            {playing ? (
              <div className="relative z-10 text-center px-6">
                <div className="text-6xl mb-4 animate-float">
                  {currentScene === 0 && '🌟'}
                  {currentScene === 1 && '🌍'}
                  {currentScene === 2 && '🏝️'}
                  {currentScene === 3 && '🗻'}
                  {currentScene === 4 && '🏛️'}
                  {currentScene === 5 && '🏠'}
                  {currentScene === 6 && '✨'}
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">
                  {filmScript.scenes[currentScene]?.title}
                </h2>
                <p className="text-white/70 text-sm max-w-lg mx-auto leading-relaxed">
                  {filmScript.scenes[currentScene]?.narration}
                </p>
                <div className="mt-4 text-xs text-white/50">
                  {filmScript.scenes[currentScene]?.time}
                </div>

                {!isPremium && progress >= 20 && (
                  <div className="mt-6 p-4 bg-black/40 backdrop-blur rounded-xl">
                    <Lock className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                    <p className="text-white font-bold">Preview Selesai</p>
                    <p className="text-white/60 text-sm mt-1">Upgrade ke Premium untuk menonton film lengkap 5 menit!</p>
                    <button
                      onClick={() => { onNavigate('license'); setPlaying(false); }}
                      className="mt-3 px-6 py-2 bg-amber-500 text-white rounded-lg text-sm font-medium hover:bg-amber-600 cursor-pointer"
                    >
                      Upgrade Premium
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="relative z-10 text-center">
                <div className="text-8xl mb-6">🌍✨</div>
                <h2 className="text-3xl font-bold text-white mb-2">{filmScript.title}</h2>
                <p className="text-white/60 text-sm mb-6">{filmScript.synopsis}</p>
                <button
                  onClick={startPlaying}
                  className="inline-flex items-center gap-3 px-8 py-4 bg-white/20 backdrop-blur rounded-2xl text-white text-lg font-semibold hover:bg-white/30 transition-all cursor-pointer group"
                >
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Play className="w-6 h-6 text-purple-700 ml-1" />
                  </div>
                  {isPremium ? 'Tonton Film Lengkap' : 'Preview 1 Menit'}
                </button>
              </div>
            )}

            {/* Progress bar */}
            {playing && (
              <div className="absolute bottom-0 left-0 right-0">
                <div className="h-1 bg-white/20">
                  <div
                    className="h-1 bg-gradient-to-r from-blue-400 to-pink-400 transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <div className="flex items-center justify-between px-4 py-2 bg-black/40">
                  <button
                    onClick={() => setPlaying(false)}
                    className="text-white/70 hover:text-white cursor-pointer"
                  >
                    <Pause className="w-5 h-5" />
                  </button>
                  <span className="text-white/50 text-xs">
                    {isPremium ? '5:00' : '1:00'} • {isPremium ? 'Full Version' : 'Preview'}
                  </span>
                  {!isPremium && (
                    <span className="flex items-center gap-1 text-amber-400 text-xs">
                      <Lock className="w-3 h-3" /> Preview
                    </span>
                  )}
                  {isPremium && (
                    <span className="flex items-center gap-1 text-yellow-400 text-xs">
                      <Crown className="w-3 h-3" /> Premium
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Film info */}
          <div className="p-6">
            <div className="flex items-center gap-4 mb-4">
              <span className="flex items-center gap-1 px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm">
                <Film className="w-4 h-4" /> Film Edukasi
              </span>
              <span className="flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                <Clock className="w-4 h-4" /> {filmScript.duration}
              </span>
              {isPremium ? (
                <span className="flex items-center gap-1 px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-sm">
                  <Crown className="w-4 h-4" /> Full Access
                </span>
              ) : (
                <span className="flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm">
                  <Lock className="w-4 h-4" /> Preview 1 Menit
                </span>
              )}
            </div>

            <h2 className="text-2xl font-bold text-gray-900 mb-2">{filmScript.title}</h2>
            <p className="text-gray-600 leading-relaxed">{filmScript.synopsis}</p>
          </div>
        </div>

        {/* Script / Scenes */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <button
            onClick={() => setShowScript(!showScript)}
            className="w-full flex items-center justify-between p-6 hover:bg-gray-50 cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-indigo-600" />
              <div className="text-left">
                <h3 className="font-bold text-gray-900">Script & Narasi</h3>
                <p className="text-gray-500 text-sm">{filmScript.scenes.length} scene lengkap dengan narasi</p>
              </div>
            </div>
            {showScript ? <ChevronUp className="w-5 h-5 text-gray-400" /> : <ChevronDown className="w-5 h-5 text-gray-400" />}
          </button>

          {showScript && (
            <div className="border-t border-gray-100 p-6 space-y-4">
              {filmScript.scenes.map((scene, i) => {
                const isLocked = !isPremium && i >= 2;
                return (
                  <div
                    key={i}
                    className={`p-4 rounded-xl border ${
                      isLocked ? 'border-gray-200 bg-gray-50 opacity-60' : 'border-indigo-100 bg-indigo-50/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-indigo-600 bg-indigo-100 px-2 py-0.5 rounded">{scene.time}</span>
                        <h4 className="font-semibold text-gray-900">{scene.title}</h4>
                      </div>
                      {isLocked && <Lock className="w-4 h-4 text-gray-400" />}
                    </div>
                    {isLocked ? (
                      <p className="text-gray-400 text-sm italic">Upgrade ke Premium untuk membaca narasi lengkap...</p>
                    ) : (
                      <p className="text-gray-600 text-sm leading-relaxed">{scene.narration}</p>
                    )}
                  </div>
                );
              })}

              {!isPremium && (
                <div className="text-center py-4">
                  <button
                    onClick={() => onNavigate('license')}
                    className="px-6 py-3 bg-gradient-to-r from-amber-400 to-orange-400 text-white rounded-xl font-medium cursor-pointer"
                  >
                    <Crown className="w-4 h-4 inline mr-2" />
                    Unlock Full Script
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Learning Videos Section */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Video Pembelajaran</h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {[
              { title: 'Belajar Huruf A-Z', icon: '🔤', duration: '3:00', color: 'from-blue-500 to-indigo-500' },
              { title: 'Belajar Angka 1-100', icon: '🔢', duration: '4:00', color: 'from-green-500 to-emerald-500' },
              { title: 'Mengenal Negara Dunia', icon: '🌍', duration: '5:00', color: 'from-purple-500 to-pink-500' },
              { title: 'Cerita Moral Anak', icon: '💖', duration: '3:30', color: 'from-rose-500 to-red-500' },
            ].map(video => (
              <div key={video.title} className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all">
                <div className={`h-32 bg-gradient-to-br ${video.color} flex items-center justify-center relative`}>
                  <span className="text-5xl">{video.icon}</span>
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 hover:opacity-100 transition-opacity cursor-pointer">
                    <div className="w-12 h-12 bg-white/90 rounded-full flex items-center justify-center">
                      <Play className="w-6 h-6 text-gray-800 ml-0.5" />
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-900">{video.title}</h3>
                  <div className="flex items-center gap-2 mt-2 text-gray-400 text-sm">
                    <Clock className="w-4 h-4" /> {video.duration}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
