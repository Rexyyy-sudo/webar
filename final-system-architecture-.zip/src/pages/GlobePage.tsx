import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../store/AuthContext';
import { countries } from '../data/modules';
import { Lock, X, Globe, MapPin, Users, Languages, Info, Crown, Search, ChevronDown } from 'lucide-react';
import * as THREE from 'three';

interface GlobePageProps {
  onNavigate: (page: string) => void;
}

export function GlobePage({ onNavigate }: GlobePageProps) {
  const { isPremium } = useAuth();
  const canvasRef = useRef<HTMLDivElement>(null);
  const [selectedCountry, setSelectedCountry] = useState<typeof countries[0] | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showList, setShowList] = useState(false);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const animRef = useRef<number>(0);

  useEffect(() => {
    if (!canvasRef.current) return;
    const container = canvasRef.current;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.z = 3;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Create Earth sphere with procedural texture
    const canvas2d = document.createElement('canvas');
    canvas2d.width = 2048;
    canvas2d.height = 1024;
    const ctx = canvas2d.getContext('2d')!;
    
    // Ocean gradient
    const oceanGrad = ctx.createLinearGradient(0, 0, 0, canvas2d.height);
    oceanGrad.addColorStop(0, '#1a5276');
    oceanGrad.addColorStop(0.3, '#2980b9');
    oceanGrad.addColorStop(0.5, '#3498db');
    oceanGrad.addColorStop(0.7, '#2980b9');
    oceanGrad.addColorStop(1, '#1a5276');
    ctx.fillStyle = oceanGrad;
    ctx.fillRect(0, 0, canvas2d.width, canvas2d.height);

    // Draw continents (simplified shapes)
    ctx.fillStyle = '#27ae60';
    // North America
    ctx.beginPath();
    ctx.ellipse(400, 300, 200, 150, -0.2, 0, Math.PI * 2);
    ctx.fill();
    // South America
    ctx.beginPath();
    ctx.ellipse(550, 600, 100, 180, 0.1, 0, Math.PI * 2);
    ctx.fill();
    // Europe
    ctx.beginPath();
    ctx.ellipse(1050, 280, 120, 80, 0, 0, Math.PI * 2);
    ctx.fill();
    // Africa
    ctx.beginPath();
    ctx.ellipse(1080, 520, 130, 180, 0, 0, Math.PI * 2);
    ctx.fill();
    // Asia
    ctx.fillStyle = '#2ecc71';
    ctx.beginPath();
    ctx.ellipse(1350, 320, 250, 160, 0, 0, Math.PI * 2);
    ctx.fill();
    // Australia
    ctx.fillStyle = '#f39c12';
    ctx.beginPath();
    ctx.ellipse(1600, 650, 100, 70, 0.2, 0, Math.PI * 2);
    ctx.fill();
    // Antarctica
    ctx.fillStyle = '#ecf0f1';
    ctx.fillRect(0, 950, canvas2d.width, 74);

    // Add some terrain variation
    for (let i = 0; i < 500; i++) {
      const x = Math.random() * canvas2d.width;
      const y = Math.random() * canvas2d.height;
      ctx.fillStyle = `rgba(${Math.random() > 0.5 ? '46,204,113' : '39,174,96'},${Math.random() * 0.3})`;
      ctx.beginPath();
      ctx.arc(x, y, Math.random() * 20 + 5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Country markers
    countries.forEach(country => {
      const x = ((country.lng + 180) / 360) * canvas2d.width;
      const y = ((90 - country.lat) / 180) * canvas2d.height;
      ctx.fillStyle = '#e74c3c';
      ctx.beginPath();
      ctx.arc(x, y, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fill();
    });

    const earthTexture = new THREE.CanvasTexture(canvas2d);
    earthTexture.needsUpdate = true;

    const earthGeometry = new THREE.SphereGeometry(1, 64, 64);
    const earthMaterial = new THREE.MeshPhongMaterial({
      map: earthTexture,
      specular: new THREE.Color(0x333333),
      shininess: 15,
    });
    const earth = new THREE.Mesh(earthGeometry, earthMaterial);
    scene.add(earth);

    // Atmosphere
    const atmosGeometry = new THREE.SphereGeometry(1.05, 64, 64);
    const atmosMaterial = new THREE.MeshPhongMaterial({
      color: 0x4488ff,
      transparent: true,
      opacity: 0.08,
      side: THREE.FrontSide,
    });
    const atmosphere = new THREE.Mesh(atmosGeometry, atmosMaterial);
    scene.add(atmosphere);

    // Clouds
    const cloudCanvas = document.createElement('canvas');
    cloudCanvas.width = 1024;
    cloudCanvas.height = 512;
    const cloudCtx = cloudCanvas.getContext('2d')!;
    cloudCtx.clearRect(0, 0, 1024, 512);
    for (let i = 0; i < 200; i++) {
      cloudCtx.fillStyle = `rgba(255,255,255,${Math.random() * 0.15})`;
      cloudCtx.beginPath();
      cloudCtx.ellipse(
        Math.random() * 1024,
        Math.random() * 512,
        Math.random() * 60 + 20,
        Math.random() * 20 + 10,
        Math.random() * Math.PI,
        0, Math.PI * 2
      );
      cloudCtx.fill();
    }
    const cloudTexture = new THREE.CanvasTexture(cloudCanvas);
    const cloudGeometry = new THREE.SphereGeometry(1.02, 64, 64);
    const cloudMaterial = new THREE.MeshPhongMaterial({
      map: cloudTexture,
      transparent: true,
      opacity: 0.4,
      depthWrite: false,
    });
    const clouds = new THREE.Mesh(cloudGeometry, cloudMaterial);
    scene.add(clouds);

    // Stars
    const starsGeometry = new THREE.BufferGeometry();
    const starsPositions = new Float32Array(3000);
    for (let i = 0; i < 3000; i++) {
      starsPositions[i] = (Math.random() - 0.5) * 100;
    }
    starsGeometry.setAttribute('position', new THREE.BufferAttribute(starsPositions, 3));
    const starsMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.05 });
    const stars = new THREE.Points(starsGeometry, starsMaterial);
    scene.add(stars);

    // Lights
    const ambientLight = new THREE.AmbientLight(0x404040, 1);
    scene.add(ambientLight);
    const sunLight = new THREE.DirectionalLight(0xffffff, 1.5);
    sunLight.position.set(5, 3, 5);
    scene.add(sunLight);

    // Mouse interaction
    let isDragging = false;
    let prevMouse = { x: 0, y: 0 };
    let rotationVelocity = { x: 0, y: 0 };

    const onPointerDown = (e: PointerEvent) => {
      isDragging = true;
      prevMouse = { x: e.clientX, y: e.clientY };
      rotationVelocity = { x: 0, y: 0 };
    };
    const onPointerMove = (e: PointerEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - prevMouse.x;
      const dy = e.clientY - prevMouse.y;
      earth.rotation.y += dx * 0.005;
      earth.rotation.x += dy * 0.005;
      earth.rotation.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, earth.rotation.x));
      clouds.rotation.y = earth.rotation.y;
      clouds.rotation.x = earth.rotation.x;
      rotationVelocity = { x: dy * 0.005, y: dx * 0.005 };
      prevMouse = { x: e.clientX, y: e.clientY };
    };
    const onPointerUp = () => { isDragging = false; };
    const onWheel = (e: WheelEvent) => {
      camera.position.z += e.deltaY * 0.002;
      camera.position.z = Math.max(1.5, Math.min(6, camera.position.z));
    };

    container.addEventListener('pointerdown', onPointerDown);
    container.addEventListener('pointermove', onPointerMove);
    container.addEventListener('pointerup', onPointerUp);
    container.addEventListener('wheel', onWheel);

    const animate = () => {
      animRef.current = requestAnimationFrame(animate);
      if (!isDragging) {
        earth.rotation.y += 0.002;
        clouds.rotation.y += 0.0025;
        // Apply momentum
        if (Math.abs(rotationVelocity.y) > 0.0001) {
          earth.rotation.y += rotationVelocity.y;
          clouds.rotation.y += rotationVelocity.y;
          rotationVelocity.y *= 0.95;
        }
      }
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('pointerdown', onPointerDown);
      container.removeEventListener('pointermove', onPointerMove);
      container.removeEventListener('pointerup', onPointerUp);
      container.removeEventListener('wheel', onWheel);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  const filteredCountries = countries.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-950 text-white relative">
      {/* Globe */}
      <div ref={canvasRef} className="w-full h-screen" style={{ touchAction: 'none' }} />

      {/* Overlay UI */}
      <div className="absolute top-4 left-4 right-4 flex items-start justify-between pointer-events-none z-10">
        <div className="pointer-events-auto">
          <div className="bg-black/60 backdrop-blur-xl rounded-2xl p-4 shadow-2xl border border-white/10">
            <h1 className="text-xl font-bold flex items-center gap-2">
              <Globe className="w-6 h-6 text-blue-400" />
              3D Globe {isPremium ? '4K' : ''}
              {isPremium && <Crown className="w-4 h-4 text-yellow-400" />}
            </h1>
            <p className="text-sm text-gray-400 mt-1">Drag untuk memutar • Scroll untuk zoom</p>
          </div>
        </div>

        {/* Country search */}
        <div className="pointer-events-auto">
          <div className="bg-black/60 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/10 w-72">
            <button
              onClick={() => setShowList(!showList)}
              className="w-full flex items-center gap-2 p-4 cursor-pointer"
            >
              <Search className="w-5 h-5 text-gray-400" />
              <span className="text-sm text-gray-300">Pilih Negara...</span>
              <ChevronDown className={`w-4 h-4 text-gray-400 ml-auto transition-transform ${showList ? 'rotate-180' : ''}`} />
            </button>
            {showList && (
              <div className="border-t border-white/10">
                <div className="p-2">
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder="Cari negara..."
                    className="w-full px-3 py-2 bg-white/10 rounded-lg text-sm text-white placeholder-gray-500 outline-none"
                  />
                </div>
                <div className="max-h-60 overflow-y-auto px-2 pb-2 space-y-1">
                  {filteredCountries.map(country => (
                    <button
                      key={country.name}
                      onClick={() => { setSelectedCountry(country); setShowList(false); }}
                      className="w-full flex items-center gap-3 px-3 py-2 hover:bg-white/10 rounded-lg text-left text-sm cursor-pointer"
                    >
                      <span className="text-xl">{country.flag}</span>
                      <span>{country.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Country detail panel */}
      {selectedCountry && (
        <div className="absolute bottom-4 left-4 right-4 md:left-auto md:right-4 md:bottom-4 md:w-96 z-20 animate-slide-up">
          <div className="bg-black/70 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/10 overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600/50 to-indigo-600/50 p-6 relative">
              <button
                onClick={() => setSelectedCountry(null)}
                className="absolute top-3 right-3 w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="text-5xl mb-2">{selectedCountry.flag}</div>
              <h2 className="text-2xl font-bold">{selectedCountry.name}</h2>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-blue-400 shrink-0" />
                <div>
                  <p className="text-xs text-gray-500">Ibukota</p>
                  <p className="font-medium">{selectedCountry.capital}</p>
                </div>
              </div>
              {(isPremium) && (
                <>
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5 text-green-400 shrink-0" />
                    <div>
                      <p className="text-xs text-gray-500">Populasi</p>
                      <p className="font-medium">{selectedCountry.population}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Languages className="w-5 h-5 text-purple-400 shrink-0" />
                    <div>
                      <p className="text-xs text-gray-500">Bahasa</p>
                      <p className="font-medium">{selectedCountry.language}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Info className="w-5 h-5 text-amber-400 shrink-0" />
                    <div>
                      <p className="text-xs text-gray-500">Fakta Menarik</p>
                      <p className="font-medium text-sm">{selectedCountry.fact}</p>
                    </div>
                  </div>
                </>
              )}
              {!isPremium && (
                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                  <div className="flex items-center gap-2 text-amber-400 text-sm font-medium mb-1">
                    <Lock className="w-4 h-4" /> Konten Premium
                  </div>
                  <p className="text-amber-200/70 text-xs">Upgrade ke Premium untuk melihat detail lengkap negara!</p>
                  <button
                    onClick={() => onNavigate('license')}
                    className="mt-3 px-4 py-2 bg-amber-500 text-white rounded-lg text-sm font-medium hover:bg-amber-600 cursor-pointer"
                  >
                    Upgrade Sekarang
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Quick country buttons */}
      <div className="absolute bottom-4 left-4 z-10 hidden md:block">
        {!selectedCountry && (
          <div className="flex flex-wrap gap-2 max-w-md">
            {countries.slice(0, 6).map(c => (
              <button
                key={c.name}
                onClick={() => setSelectedCountry(c)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-black/50 backdrop-blur rounded-full text-sm hover:bg-black/70 cursor-pointer border border-white/10"
              >
                <span>{c.flag}</span>
                <span className="text-gray-300">{c.name}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
