import { useState } from 'react';
import { useAuth } from '../store/AuthContext';
import { Scan, Lock, Crown, Camera, Sparkles, RotateCw, ChevronRight } from 'lucide-react';

interface ScannerPageProps {
  onNavigate: (page: string) => void;
}

interface ARCard {
  id: string;
  name: string;
  icon: string;
  model: string;
  description: string;
  premium: boolean;
  color: string;
}

const arCards: ARCard[] = [
  { id: 'ar-earth', name: 'Bumi', icon: '🌍', model: 'Earth 3D Model', description: 'Lihat model bumi berputar di atas kartu!', premium: false, color: 'from-blue-500 to-cyan-500' },
  { id: 'ar-dino', name: 'Dinosaurus', icon: '🦕', model: 'T-Rex 3D', description: 'T-Rex hidup di atas meja belajarmu!', premium: false, color: 'from-green-500 to-emerald-500' },
  { id: 'ar-solar', name: 'Tata Surya', icon: '☀️', model: 'Solar System', description: 'Semua planet berputar di atas kartu!', premium: false, color: 'from-amber-500 to-orange-500' },
  { id: 'ar-anatomy', name: 'Tubuh Manusia', icon: '🫀', model: 'Human Body', description: 'Jelajahi organ tubuh manusia!', premium: true, color: 'from-red-500 to-rose-500' },
  { id: 'ar-volcano', name: 'Gunung Berapi', icon: '🌋', model: 'Volcano Eruption', description: 'Lihat letusan gunung berapi!', premium: true, color: 'from-orange-600 to-red-600' },
  { id: 'ar-butterfly', name: 'Kupu-kupu', icon: '🦋', model: 'Butterfly Lifecycle', description: 'Metamorfosis kupu-kupu lengkap!', premium: true, color: 'from-purple-500 to-pink-500' },
  { id: 'ar-whale', name: 'Paus Biru', icon: '🐋', model: 'Blue Whale', description: 'Paus biru berenang di depanmu!', premium: true, color: 'from-blue-600 to-indigo-600' },
  { id: 'ar-rocket', name: 'Roket', icon: '🚀', model: 'Space Rocket', description: 'Lihat roket meluncur ke luar angkasa!', premium: true, color: 'from-gray-600 to-blue-600' },
];

export function ScannerPage({ onNavigate }: ScannerPageProps) {
  const { isPremium } = useAuth();
  const [selectedCard, setSelectedCard] = useState<ARCard | null>(null);
  const [scanning, setScanning] = useState(false);
  const [arActive, setArActive] = useState(false);

  const canAccess = (card: ARCard) => !card.premium || isPremium;
  const accessibleCards = arCards.filter(c => canAccess(c));
  const lockedCards = arCards.filter(c => !canAccess(c));

  const startScanning = (card: ARCard) => {
    if (!canAccess(card)) {
      onNavigate('license');
      return;
    }
    setSelectedCard(card);
    setScanning(true);
    // Simulate scan delay
    setTimeout(() => {
      setScanning(false);
      setArActive(true);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* AR Active View */}
      {arActive && selectedCard && (
        <div className="fixed inset-0 z-50 bg-black">
          <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-900 to-black">
            {/* Simulated camera feed */}
            <div className="absolute inset-0 bg-gradient-to-br from-gray-800 via-gray-900 to-black opacity-80" />
            
            {/* AR Content */}
            <div className="relative text-center animate-slide-up">
              <div className="relative inline-block">
                {/* Card frame */}
                <div className="w-64 h-40 border-2 border-green-400 rounded-xl flex items-center justify-center bg-white/5 backdrop-blur">
                  <div className="text-center">
                    <div className="text-6xl mb-2 animate-float">{selectedCard.icon}</div>
                    <div className="text-white font-bold text-lg">{selectedCard.name}</div>
                    <div className="text-green-400 text-sm mt-1">{selectedCard.model}</div>
                  </div>
                </div>
                
                {/* Corner markers */}
                <div className="absolute -top-2 -left-2 w-6 h-6 border-t-2 border-l-2 border-green-400 rounded-tl-lg" />
                <div className="absolute -top-2 -right-2 w-6 h-6 border-t-2 border-r-2 border-green-400 rounded-tr-lg" />
                <div className="absolute -bottom-2 -left-2 w-6 h-6 border-b-2 border-l-2 border-green-400 rounded-bl-lg" />
                <div className="absolute -bottom-2 -right-2 w-6 h-6 border-b-2 border-r-2 border-green-400 rounded-br-lg" />
              </div>

              <p className="text-green-400 text-sm mt-6 flex items-center justify-center gap-2">
                <Sparkles className="w-4 h-4" />
                AR Model Active — {selectedCard.description}
              </p>

              {/* 3D Model visualization */}
              <div className="mt-8 relative">
                <div className="w-48 h-48 mx-auto rounded-full bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center animate-pulse-glow">
                  <div className="text-8xl animate-float">{selectedCard.icon}</div>
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-56 h-56 rounded-full border border-blue-400/20 animate-spin" style={{ animationDuration: '8s' }}>
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 bg-blue-400 rounded-full" />
                  </div>
                </div>
              </div>
            </div>

            {/* Close button */}
            <button
              onClick={() => { setArActive(false); setSelectedCard(null); }}
              className="absolute top-6 right-6 px-4 py-2 bg-white/10 backdrop-blur rounded-full text-white text-sm font-medium hover:bg-white/20 cursor-pointer"
            >
              Tutup AR
            </button>

            {/* Info bar */}
            <div className="absolute bottom-6 left-6 right-6">
              <div className="bg-black/60 backdrop-blur-xl rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-white">{selectedCard.name}</h3>
                  <p className="text-gray-400 text-sm">{selectedCard.description}</p>
                </div>
                <button
                  onClick={() => { setArActive(false); setSelectedCard(null); }}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm cursor-pointer"
                >
                  Stop
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Scanning overlay */}
      {scanning && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center">
          <div className="text-center text-white">
            <div className="w-24 h-24 mx-auto mb-6 relative">
              <div className="absolute inset-0 border-4 border-blue-500 rounded-2xl animate-pulse-glow" />
              <div className="absolute inset-2 flex items-center justify-center">
                <Camera className="w-10 h-10 text-blue-400 animate-pulse" />
              </div>
            </div>
            <h2 className="text-xl font-bold mb-2">Memindai Kartu...</h2>
            <p className="text-gray-400 text-sm">Arahkan kamera ke kartu {selectedCard?.name}</p>
            <RotateCw className="w-6 h-6 text-blue-400 mx-auto mt-4 animate-spin" />
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Scan className="w-8 h-8 text-purple-600" />
            WebAR Scanner
          </h1>
          <p className="text-gray-500 mt-2">Scan kartu untuk melihat model 3D muncul di dunia nyata!</p>
        </div>

        {/* How it works */}
        <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl p-6 mb-8">
          <h2 className="font-bold text-gray-900 mb-4">Cara Menggunakan:</h2>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { step: '1', text: 'Pilih kartu AR yang ingin kamu scan', icon: '🎴' },
              { step: '2', text: 'Arahkan kamera ke kartu fisik atau marker', icon: '📱' },
              { step: '3', text: 'Lihat model 3D muncul di layar!', icon: '✨' },
            ].map(s => (
              <div key={s.step} className="flex items-center gap-3 bg-white rounded-xl p-4">
                <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center text-xl">{s.icon}</div>
                <div>
                  <span className="text-xs text-purple-600 font-bold">Step {s.step}</span>
                  <p className="text-sm text-gray-700">{s.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Available cards */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-500" />
            Kartu AR Tersedia ({accessibleCards.length})
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {accessibleCards.map(card => (
              <button
                key={card.id}
                onClick={() => startScanning(card)}
                className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all text-left cursor-pointer"
              >
                <div className={`h-28 bg-gradient-to-br ${card.color} flex items-center justify-center relative`}>
                  <span className="text-5xl group-hover:scale-110 transition-transform">{card.icon}</span>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-900">{card.name}</h3>
                  <p className="text-gray-500 text-xs mt-1">{card.description}</p>
                  <div className="flex items-center gap-1 mt-3 text-purple-600 text-sm font-medium">
                    <Camera className="w-4 h-4" /> Scan
                    <ChevronRight className="w-4 h-4 ml-auto" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Locked cards */}
        {lockedCards.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Lock className="w-5 h-5 text-amber-500" />
              Kartu Premium ({lockedCards.length})
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {lockedCards.map(card => (
                <button
                  key={card.id}
                  onClick={() => onNavigate('license')}
                  className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all text-left cursor-pointer opacity-75 hover:opacity-100"
                >
                  <div className={`h-28 bg-gradient-to-br ${card.color} flex items-center justify-center relative`}>
                    <span className="text-5xl blur-sm">{card.icon}</span>
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <div className="flex items-center gap-1.5 px-3 py-1.5 bg-black/50 rounded-full text-white text-xs">
                        <Crown className="w-3 h-3 text-yellow-400" /> Premium
                      </div>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-gray-900">{card.name}</h3>
                    <p className="text-gray-400 text-xs mt-1">{card.description}</p>
                    <div className="flex items-center gap-1 mt-3 text-amber-500 text-sm font-medium">
                      <Lock className="w-4 h-4" /> Unlock
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
