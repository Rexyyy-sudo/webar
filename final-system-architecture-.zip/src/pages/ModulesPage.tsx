import { useState } from 'react';
import { useAuth } from '../store/AuthContext';
import { modules, type LearningModule, type QuizItem } from '../data/modules';
import { Lock, ArrowLeft, CheckCircle, XCircle, ChevronRight, Crown, BookOpen, Trophy, Star } from 'lucide-react';

interface ModulesPageProps {
  onNavigate: (page: string) => void;
}

export function ModulesPage({ onNavigate }: ModulesPageProps) {
  const { isPremium, isLoggedIn } = useAuth();
  const [selectedModule, setSelectedModule] = useState<LearningModule | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<number | null>(null);
  const [quizState, setQuizState] = useState<{
    currentQ: number;
    score: number;
    answered: boolean;
    selectedAnswer: number | null;
    completed: boolean;
  }>({ currentQ: 0, score: 0, answered: false, selectedAnswer: null, completed: false });

  const canAccess = (mod: LearningModule) => !mod.premium || isPremium;

  const handleModuleClick = (mod: LearningModule) => {
    if (!canAccess(mod)) {
      onNavigate('license');
      return;
    }
    setSelectedModule(mod);
    setSelectedLesson(null);
    setQuizState({ currentQ: 0, score: 0, answered: false, selectedAnswer: null, completed: false });
  };

  const handleAnswer = (idx: number, items: QuizItem[]) => {
    if (quizState.answered) return;
    const isCorrect = idx === items[quizState.currentQ].correct;
    setQuizState(prev => ({
      ...prev,
      answered: true,
      selectedAnswer: idx,
      score: isCorrect ? prev.score + 1 : prev.score
    }));
  };

  const nextQuestion = (items: QuizItem[]) => {
    if (quizState.currentQ + 1 >= items.length) {
      setQuizState(prev => ({ ...prev, completed: true }));
    } else {
      setQuizState(prev => ({
        ...prev,
        currentQ: prev.currentQ + 1,
        answered: false,
        selectedAnswer: null
      }));
    }
  };

  const categories = [
    { id: 'all', label: 'Semua' },
    { id: 'literacy', label: '📖 Literasi' },
    { id: 'numeracy', label: '🔢 Numerasi' },
    { id: 'world', label: '🌍 Dunia' },
    { id: 'creative', label: '🎨 Kreatif' },
    { id: 'science', label: '🔬 Sains' },
    { id: 'character', label: '💖 Karakter' },
  ];
  const [activeCategory, setActiveCategory] = useState('all');
  const filteredModules = activeCategory === 'all' ? modules : modules.filter(m => m.category === activeCategory);

  // Module list view
  if (!selectedModule) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <BookOpen className="w-8 h-8 text-blue-600" />
              Modul Pembelajaran
            </h1>
            <p className="text-gray-500 mt-2">9 modul interaktif dengan kuis dan materi lengkap</p>
          </div>

          {/* Category filter */}
          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredModules.map(mod => {
              const locked = !canAccess(mod);
              return (
                <button
                  key={mod.id}
                  onClick={() => handleModuleClick(mod)}
                  className={`group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 text-left cursor-pointer ${
                    locked ? 'opacity-80' : ''
                  }`}
                >
                  <div className={`h-32 bg-gradient-to-br ${mod.gradient} flex items-center justify-center relative`}>
                    <span className="text-6xl group-hover:scale-110 transition-transform">{mod.icon}</span>
                    {locked && (
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <div className="flex items-center gap-2 px-4 py-2 bg-black/50 rounded-full text-white text-sm">
                          <Lock className="w-4 h-4" /> Premium Only
                        </div>
                      </div>
                    )}
                    {mod.premium && !locked && (
                      <div className="absolute top-3 right-3">
                        <Crown className="w-5 h-5 text-yellow-300" />
                      </div>
                    )}
                  </div>
                  <div className="p-5">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-bold text-gray-900 text-lg">{mod.title}</h3>
                        <p className="text-xs text-gray-400 mt-0.5">{mod.titleEn}</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-blue-500 transition-colors mt-1" />
                    </div>
                    <p className="text-gray-500 text-sm mt-2 line-clamp-2">{mod.description}</p>
                    <div className="flex items-center gap-3 mt-4 text-xs text-gray-400">
                      <span>{mod.lessons.length} pelajaran</span>
                      <span>•</span>
                      <span>{mod.lessons.filter(l => l.type === 'quiz').length} kuis</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {!isLoggedIn && (
            <div className="mt-12 text-center">
              <div className="inline-flex flex-col items-center gap-4 p-8 bg-blue-50 rounded-2xl">
                <p className="text-gray-600">Masuk untuk menyimpan progress belajar kamu!</p>
                <button onClick={() => onNavigate('login')} className="px-6 py-3 bg-blue-600 text-white rounded-xl font-medium cursor-pointer">
                  Masuk Sekarang
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Lesson view
  const lesson = selectedLesson !== null ? selectedModule.lessons[selectedLesson] : null;

  if (lesson) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-3xl mx-auto px-4">
          <button
            onClick={() => { setSelectedLesson(null); setQuizState({ currentQ: 0, score: 0, answered: false, selectedAnswer: null, completed: false }); }}
            className="flex items-center gap-2 text-gray-500 hover:text-gray-700 mb-6 cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" /> Kembali ke {selectedModule.title}
          </button>

          <div className={`bg-gradient-to-br ${selectedModule.gradient} rounded-2xl p-6 text-white mb-8`}>
            <div className="text-4xl mb-3">{selectedModule.icon}</div>
            <h1 className="text-2xl font-bold">{lesson.title}</h1>
            <p className="text-white/70 text-sm mt-1">
              {lesson.type === 'quiz' ? '🎯 Kuis Interaktif' : '📖 Materi Pembelajaran'}
            </p>
          </div>

          {lesson.type === 'text' && (
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <div className="prose max-w-none text-gray-700 text-lg leading-relaxed whitespace-pre-line">
                {lesson.content}
              </div>
              <div className="mt-8 flex justify-between">
                <button
                  onClick={() => { setSelectedLesson(null); }}
                  className="px-6 py-3 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 cursor-pointer"
                >
                  ← Kembali
                </button>
                {selectedLesson !== null && selectedLesson < selectedModule.lessons.length - 1 && (
                  <button
                    onClick={() => { setSelectedLesson((selectedLesson ?? 0) + 1); setQuizState({ currentQ: 0, score: 0, answered: false, selectedAnswer: null, completed: false }); }}
                    className="px-6 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 cursor-pointer"
                  >
                    Lanjut →
                  </button>
                )}
              </div>
            </div>
          )}

          {lesson.type === 'quiz' && lesson.items && !quizState.completed && (
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <span className="text-sm text-gray-400">Pertanyaan {quizState.currentQ + 1} dari {lesson.items.length}</span>
                <span className="flex items-center gap-1 text-sm font-medium text-blue-600">
                  <Star className="w-4 h-4" /> Skor: {quizState.score}
                </span>
              </div>
              {/* Progress bar */}
              <div className="w-full h-2 bg-gray-100 rounded-full mb-8">
                <div
                  className="h-2 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full transition-all duration-500"
                  style={{ width: `${((quizState.currentQ + 1) / lesson.items.length) * 100}%` }}
                />
              </div>

              <h2 className="text-xl font-bold text-gray-900 mb-6">{lesson.items[quizState.currentQ].question}</h2>
              <div className="space-y-3">
                {lesson.items[quizState.currentQ].options.map((opt, idx) => {
                  const isCorrect = idx === lesson.items![quizState.currentQ].correct;
                  const isSelected = quizState.selectedAnswer === idx;
                  let style = 'border-gray-200 hover:border-blue-300 hover:bg-blue-50';
                  if (quizState.answered) {
                    if (isCorrect) style = 'border-green-500 bg-green-50';
                    else if (isSelected) style = 'border-red-500 bg-red-50';
                    else style = 'border-gray-200 opacity-50';
                  }
                  return (
                    <button
                      key={idx}
                      onClick={() => handleAnswer(idx, lesson.items!)}
                      disabled={quizState.answered}
                      className={`w-full flex items-center gap-3 p-4 rounded-xl border-2 text-left transition-all cursor-pointer ${style}`}
                    >
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold shrink-0 ${
                        quizState.answered && isCorrect ? 'bg-green-500 text-white' :
                        quizState.answered && isSelected ? 'bg-red-500 text-white' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span className="text-gray-700 font-medium">{opt}</span>
                      {quizState.answered && isCorrect && <CheckCircle className="w-5 h-5 text-green-500 ml-auto" />}
                      {quizState.answered && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-red-500 ml-auto" />}
                    </button>
                  );
                })}
              </div>

              {quizState.answered && lesson.items[quizState.currentQ].explanation && (
                <div className="mt-4 p-4 bg-blue-50 rounded-xl text-blue-700 text-sm">
                  💡 {lesson.items[quizState.currentQ].explanation}
                </div>
              )}

              {quizState.answered && (
                <button
                  onClick={() => nextQuestion(lesson.items!)}
                  className="mt-6 w-full py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 cursor-pointer"
                >
                  {quizState.currentQ + 1 >= lesson.items.length ? 'Lihat Hasil' : 'Pertanyaan Selanjutnya →'}
                </button>
              )}
            </div>
          )}

          {lesson.type === 'quiz' && quizState.completed && lesson.items && (
            <div className="bg-white rounded-2xl p-8 shadow-sm text-center">
              <div className="text-6xl mb-4">
                {quizState.score === lesson.items.length ? '🏆' : quizState.score >= lesson.items.length / 2 ? '⭐' : '💪'}
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                {quizState.score === lesson.items.length ? 'Sempurna!' : quizState.score >= lesson.items.length / 2 ? 'Bagus Sekali!' : 'Terus Belajar!'}
              </h2>
              <p className="text-gray-500 mb-6">
                Kamu menjawab benar {quizState.score} dari {lesson.items.length} pertanyaan
              </p>
              <div className="flex items-center justify-center gap-2 mb-8">
                {lesson.items.map((_, i) => (
                  <div key={i} className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    i < quizState.score ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    {i < quizState.score ? <CheckCircle className="w-5 h-5 text-green-500" /> : <XCircle className="w-5 h-5 text-red-500" />}
                  </div>
                ))}
              </div>
              <div className="flex gap-4 justify-center">
                <button
                  onClick={() => setQuizState({ currentQ: 0, score: 0, answered: false, selectedAnswer: null, completed: false })}
                  className="px-6 py-3 bg-blue-100 text-blue-700 rounded-xl font-medium hover:bg-blue-200 cursor-pointer"
                >
                  Ulangi Kuis
                </button>
                <button
                  onClick={() => setSelectedLesson(null)}
                  className="px-6 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 cursor-pointer"
                >
                  Kembali ke Modul
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Module detail (lesson list)
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-3xl mx-auto px-4">
        <button
          onClick={() => setSelectedModule(null)}
          className="flex items-center gap-2 text-gray-500 hover:text-gray-700 mb-6 cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" /> Semua Modul
        </button>

        <div className={`bg-gradient-to-br ${selectedModule.gradient} rounded-2xl p-8 text-white mb-8`}>
          <span className="text-6xl block mb-4">{selectedModule.icon}</span>
          <h1 className="text-3xl font-bold">{selectedModule.title}</h1>
          <p className="text-white/70 text-sm mt-1">{selectedModule.titleEn}</p>
          <p className="text-white/80 mt-3">{selectedModule.description}</p>
          <div className="flex items-center gap-4 mt-4 text-white/60 text-sm">
            <span className="flex items-center gap-1"><BookOpen className="w-4 h-4" /> {selectedModule.lessons.length} Pelajaran</span>
            <span className="flex items-center gap-1"><Trophy className="w-4 h-4" /> {selectedModule.lessons.filter(l => l.type === 'quiz').length} Kuis</span>
          </div>
        </div>

        <div className="space-y-3">
          {selectedModule.lessons.map((les, i) => (
            <button
              key={les.id}
              onClick={() => { setSelectedLesson(i); setQuizState({ currentQ: 0, score: 0, answered: false, selectedAnswer: null, completed: false }); }}
              className="w-full flex items-center gap-4 p-5 bg-white rounded-xl shadow-sm hover:shadow-md transition-all text-left cursor-pointer group"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${selectedModule.gradient} flex items-center justify-center text-white font-bold shrink-0`}>
                {i + 1}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">{les.title}</h3>
                <p className="text-sm text-gray-400 mt-0.5">
                  {les.type === 'quiz' ? `🎯 Kuis • ${les.items?.length || 0} pertanyaan` : '📖 Materi pembelajaran'}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-blue-500" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
