import { useState } from 'react';
import { useAuth } from '../store/AuthContext';
import { School, Users, Calendar, Shield, CheckCircle, Building, Crown, BarChart3, Settings, BookOpen } from 'lucide-react';

interface SchoolPageProps {
  onNavigate: (page: string) => void;
}

export function SchoolPage({ onNavigate }: SchoolPageProps) {
  const { isLoggedIn, school, activateSchool } = useAuth();
  const [schoolName, setSchoolName] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<string>('basic');

  const plans = [
    {
      id: 'basic',
      name: 'Starter',
      price: 'Rp 199.000/thn',
      maxUsers: 30,
      features: ['30 akun siswa', 'Semua modul', '3D Globe', 'Laporan dasar', 'Email support'],
      color: 'from-blue-500 to-indigo-500',
    },
    {
      id: 'pro',
      name: 'Professional',
      price: 'Rp 499.000/thn',
      maxUsers: 100,
      features: ['100 akun siswa', 'Semua fitur premium', 'Dashboard admin', 'Laporan detail', 'Prioritas support', 'Custom branding'],
      color: 'from-purple-500 to-indigo-600',
      popular: true,
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: 'Rp 999.000/thn',
      maxUsers: 500,
      features: ['500 akun siswa', 'API access', 'Multi-cabang', 'Training guru', 'Account manager', 'SLA 99.9%', 'Custom module'],
      color: 'from-emerald-500 to-teal-600',
    },
  ];

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <School className="w-16 h-16 text-teal-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Lisensi Sekolah</h2>
          <p className="text-gray-500 mb-6">Masuk terlebih dahulu untuk mendaftarkan sekolah Anda.</p>
          <button
            onClick={() => onNavigate('login')}
            className="px-8 py-3 bg-teal-600 text-white rounded-xl font-medium hover:bg-teal-700 cursor-pointer"
          >
            Masuk Sekarang
          </button>
        </div>
      </div>
    );
  }

  if (school) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-5xl mx-auto px-4">
          <div className="bg-gradient-to-br from-teal-500 to-emerald-600 rounded-3xl p-8 text-white shadow-2xl mb-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
                <Building className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">{school.name}</h1>
                <p className="text-white/70">Plan: {school.plan.toUpperCase()}</p>
              </div>
              <span className="ml-auto px-4 py-2 bg-white/20 rounded-full text-sm font-bold">AKTIF</span>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white/10 rounded-xl p-4 text-center">
                <Users className="w-6 h-6 mx-auto mb-1" />
                <div className="text-2xl font-bold">{school.maxUsers}</div>
                <div className="text-xs text-white/70">Max Users</div>
              </div>
              <div className="bg-white/10 rounded-xl p-4 text-center">
                <Calendar className="w-6 h-6 mx-auto mb-1" />
                <div className="text-sm font-bold">{new Date(school.activeUntil).toLocaleDateString('id-ID')}</div>
                <div className="text-xs text-white/70">Aktif Sampai</div>
              </div>
              <div className="bg-white/10 rounded-xl p-4 text-center">
                <Shield className="w-6 h-6 mx-auto mb-1" />
                <div className="text-lg font-bold">✅</div>
                <div className="text-xs text-white/70">Terverifikasi</div>
              </div>
            </div>
          </div>

          {/* Dashboard simulasi */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h2 className="font-bold text-gray-900 flex items-center gap-2 mb-4">
                <BarChart3 className="w-5 h-5 text-blue-500" /> Statistik Penggunaan
              </h2>
              <div className="space-y-4">
                {[
                  { label: 'Total Siswa Aktif', value: '24', max: school.maxUsers, color: 'bg-blue-500' },
                  { label: 'Modul Diselesaikan', value: '156', max: 300, color: 'bg-green-500' },
                  { label: 'Rata-rata Skor Kuis', value: '78%', max: 100, color: 'bg-purple-500' },
                ].map(stat => (
                  <div key={stat.label}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">{stat.label}</span>
                      <span className="font-bold text-gray-900">{stat.value}</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className={`h-2 ${stat.color} rounded-full`} style={{ width: `${(parseInt(stat.value) / stat.max) * 100}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h2 className="font-bold text-gray-900 flex items-center gap-2 mb-4">
                <Settings className="w-5 h-5 text-gray-500" /> Quick Actions
              </h2>
              <div className="space-y-3">
                {[
                  { icon: Users, label: 'Kelola Siswa', desc: 'Tambah atau hapus akun siswa' },
                  { icon: BookOpen, label: 'Assign Modul', desc: 'Atur modul untuk kelas' },
                  { icon: BarChart3, label: 'Lihat Laporan', desc: 'Laporan progress siswa' },
                  { icon: Settings, label: 'Pengaturan', desc: 'Konfigurasi sekolah' },
                ].map(action => {
                  const Icon = action.icon;
                  return (
                    <button key={action.label} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 text-left cursor-pointer">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                        <Icon className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900 text-sm">{action.label}</div>
                        <div className="text-xs text-gray-400">{action.desc}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-5xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <School className="w-8 h-8 text-teal-600" />
            Lisensi Sekolah
          </h1>
          <p className="text-gray-500 mt-2">Platform SaaS untuk institusi pendidikan</p>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {plans.map(plan => (
            <button
              key={plan.id}
              onClick={() => setSelectedPlan(plan.id)}
              className={`relative bg-white rounded-2xl p-6 shadow-sm text-left transition-all cursor-pointer ${
                selectedPlan === plan.id
                  ? 'ring-2 ring-teal-500 shadow-lg'
                  : 'hover:shadow-md'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-gradient-to-r from-purple-500 to-indigo-500 text-white text-xs font-bold rounded-full">
                  POPULER
                </div>
              )}
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-4`}>
                <Crown className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">{plan.name}</h3>
              <div className="text-2xl font-extrabold text-gray-900 mt-1">{plan.price}</div>
              <div className="text-sm text-gray-400 mb-4">Max {plan.maxUsers} siswa</div>
              <ul className="space-y-2">
                {plan.features.map(f => (
                  <li key={f} className="flex items-center gap-2 text-sm text-gray-600">
                    <CheckCircle className="w-4 h-4 text-green-500 shrink-0" /> {f}
                  </li>
                ))}
              </ul>
              {selectedPlan === plan.id && (
                <div className="absolute top-3 right-3 w-6 h-6 bg-teal-500 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
              )}
            </button>
          ))}
        </div>

        {/* Registration form */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-gradient-to-r from-teal-500 to-emerald-500 p-6 text-white">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Building className="w-6 h-6" />
              Daftarkan Sekolah Anda
            </h2>
            <p className="text-white/80 text-sm mt-1">
              Plan: {plans.find(p => p.id === selectedPlan)?.name} — {plans.find(p => p.id === selectedPlan)?.price}
            </p>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nama Sekolah</label>
                <input
                  type="text"
                  value={schoolName}
                  onChange={e => setSchoolName(e.target.value)}
                  placeholder="contoh: SD Negeri 1 Jakarta"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none"
                />
              </div>
              <button
                onClick={() => {
                  if (schoolName.trim()) {
                    activateSchool(schoolName, selectedPlan);
                  }
                }}
                disabled={!schoolName.trim()}
                className="w-full py-3 bg-gradient-to-r from-teal-500 to-emerald-500 text-white rounded-xl font-semibold hover:shadow-lg transition-all disabled:opacity-50 cursor-pointer"
              >
                Daftarkan Sekolah
              </button>
            </div>

            <div className="mt-4 p-4 bg-teal-50 rounded-xl">
              <p className="text-xs text-teal-600 font-medium">💡 Demo: Masukkan nama sekolah untuk simulasi pendaftaran.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
