import { useState } from 'react';
import { useAuth } from '../store/AuthContext';
import { CreditCard, Crown, CheckCircle, Key, ShieldCheck, Sparkles, Gift, AlertCircle } from 'lucide-react';

interface LicensePageProps {
  onNavigate: (page: string) => void;
}

export function LicensePage({ onNavigate }: LicensePageProps) {
  const { isLoggedIn, isPremium, user, activateLicense } = useAuth();
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleActivate = async () => {
    if (!code.trim()) return;
    setLoading(true);
    setResult(null);
    
    // Simulate API call
    await new Promise(r => setTimeout(r, 1500));
    const res = await activateLicense(code.trim());
    setResult(res);
    setLoading(false);
    if (res.success) setCode('');
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <Key className="w-16 h-16 text-blue-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Masuk Terlebih Dahulu</h2>
          <p className="text-gray-500 mb-6">Kamu perlu login untuk mengaktivasi lisensi premium.</p>
          <button
            onClick={() => onNavigate('login')}
            className="px-8 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 cursor-pointer"
          >
            Masuk Sekarang
          </button>
        </div>
      </div>
    );
  }

  if (isPremium) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-3xl mx-auto px-4">
          <div className="bg-gradient-to-br from-amber-400 via-yellow-400 to-orange-400 rounded-3xl p-8 text-center text-white shadow-2xl">
            <Crown className="w-20 h-20 mx-auto mb-4 drop-shadow-lg" />
            <h1 className="text-3xl font-extrabold mb-2">Akun Premium Aktif! 🎉</h1>
            <p className="text-white/80 mb-4">Selamat, {user?.name}! Kamu memiliki akses penuh ke semua fitur.</p>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 rounded-full text-sm">
              <ShieldCheck className="w-4 h-4" />
              Lisensi: {user?.activatedLicense}
            </div>
          </div>

          <div className="mt-8 bg-white rounded-2xl p-6 shadow-sm">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Fitur Premium Kamu:</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {[
                '3D Globe 4K dengan detail lengkap',
                'Semua 9 modul pembelajaran',
                'Film edukasi 5 menit penuh',
                'Semua kartu AR (8 kartu)',
                'Script narasi lengkap',
                'Mode offline penuh',
                'Detail negara lengkap',
                'Update konten berkala',
              ].map(f => (
                <div key={f} className="flex items-center gap-2 p-3 bg-green-50 rounded-xl">
                  <CheckCircle className="w-5 h-5 text-green-500 shrink-0" />
                  <span className="text-gray-700 text-sm">{f}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 text-center">
            <button
              onClick={() => onNavigate('modules')}
              className="px-6 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 cursor-pointer"
            >
              Mulai Belajar →
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-3xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <CreditCard className="w-8 h-8 text-amber-600" />
            Aktivasi Premium
          </h1>
          <p className="text-gray-500 mt-2">Masukkan kode premium dari kartu fisik atau pembelian online</p>
        </div>

        {/* Activation form */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-8">
          <div className="bg-gradient-to-r from-amber-500 to-orange-500 p-6 text-white">
            <div className="flex items-center gap-3 mb-2">
              <Gift className="w-6 h-6" />
              <h2 className="text-xl font-bold">Kode Aktivasi</h2>
            </div>
            <p className="text-white/80 text-sm">Masukkan kode 16 karakter dari kartu premium kamu</p>
          </div>
          <div className="p-6">
            <div className="flex gap-3">
              <input
                type="text"
                value={code}
                onChange={e => setCode(e.target.value.toUpperCase())}
                placeholder="XXXX-XXXX-XXXX"
                className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-xl text-lg font-mono text-center tracking-widest focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
              />
              <button
                onClick={handleActivate}
                disabled={loading || !code.trim()}
                className="px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-xl font-semibold hover:shadow-lg transition-all disabled:opacity-50 cursor-pointer whitespace-nowrap"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
                ) : (
                  'Aktivasi'
                )}
              </button>
            </div>

            {result && (
              <div className={`mt-4 p-4 rounded-xl flex items-center gap-3 ${
                result.success ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
              }`}>
                {result.success ? <CheckCircle className="w-5 h-5 shrink-0" /> : <AlertCircle className="w-5 h-5 shrink-0" />}
                <span className="font-medium">{result.message}</span>
              </div>
            )}

            <div className="mt-4 p-4 bg-blue-50 rounded-xl">
              <p className="text-xs text-blue-600 font-medium mb-1">💡 Demo: Gunakan kode berikut untuk mencoba</p>
              <div className="flex flex-wrap gap-2 mt-2">
                {['DEMO-PREMIUM-123', 'EDUCARD-PREMIUM-2024', 'AKSA-GLOBE-VIP'].map(c => (
                  <button
                    key={c}
                    onClick={() => setCode(c)}
                    className="px-3 py-1.5 bg-blue-100 text-blue-700 rounded-lg text-xs font-mono hover:bg-blue-200 cursor-pointer"
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* How it works */}
        <div className="bg-white rounded-2xl p-6 shadow-sm mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-500" />
            Cara Mendapatkan Kode Premium
          </h2>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { step: '1', title: 'Beli Kartu', desc: 'Beli kartu EduCard di toko terdekat atau online', icon: '🛒' },
              { step: '2', title: 'Gosok Kode', desc: 'Gosok bagian belakang kartu untuk melihat kode', icon: '🎫' },
              { step: '3', title: 'Aktivasi', desc: 'Masukkan kode di atas dan nikmati Premium!', icon: '✅' },
            ].map(s => (
              <div key={s.step} className="text-center p-4">
                <div className="text-4xl mb-3">{s.icon}</div>
                <div className="text-xs text-purple-600 font-bold mb-1">Step {s.step}</div>
                <h3 className="font-semibold text-gray-900 mb-1">{s.title}</h3>
                <p className="text-gray-500 text-sm">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Premium comparison */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Basic vs Premium</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-3 px-2 text-gray-500 font-medium">Fitur</th>
                  <th className="text-center py-3 px-2 text-gray-500 font-medium">Basic</th>
                  <th className="text-center py-3 px-2 text-amber-600 font-medium">Premium</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { feature: 'Modul Pembelajaran', basic: '5 modul', premium: '9 modul' },
                  { feature: '3D Globe', basic: 'Preview', premium: '4K Detail Lengkap' },
                  { feature: 'Film Edukasi', basic: '1 menit', premium: '5 menit penuh' },
                  { feature: 'Kartu AR', basic: '3 kartu', premium: '8 kartu' },
                  { feature: 'Detail Negara', basic: 'Terbatas', premium: 'Lengkap' },
                  { feature: 'Script Narasi', basic: '❌', premium: '✅' },
                  { feature: 'Mode Offline', basic: 'Terbatas', premium: 'Penuh' },
                ].map(row => (
                  <tr key={row.feature} className="border-b border-gray-50">
                    <td className="py-3 px-2 font-medium text-gray-900">{row.feature}</td>
                    <td className="py-3 px-2 text-center text-gray-500">{row.basic}</td>
                    <td className="py-3 px-2 text-center text-amber-600 font-medium">{row.premium}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
