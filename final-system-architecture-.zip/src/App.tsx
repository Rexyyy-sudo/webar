import { useState, useEffect } from 'react';
import { AuthProvider } from './store/AuthContext';
import { Navbar } from './components/Navbar';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/LoginPage';
import { ModulesPage } from './pages/ModulesPage';
import { GlobePage } from './pages/GlobePage';
import { ScannerPage } from './pages/ScannerPage';
import { FilmsPage } from './pages/FilmsPage';
import { LicensePage } from './pages/LicensePage';
import { SchoolPage } from './pages/SchoolPage';

function AppContent() {
  const [currentPage, setCurrentPage] = useState('home');

  // Handle browser back/forward
  useEffect(() => {
    const handlePopState = () => {
      const hash = window.location.hash.slice(1) || 'home';
      setCurrentPage(hash);
    };
    window.addEventListener('popstate', handlePopState);
    
    // Set initial page from hash
    const initialHash = window.location.hash.slice(1);
    if (initialHash) setCurrentPage(initialHash);
    
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (page: string) => {
    setCurrentPage(page);
    window.location.hash = page;
    window.scrollTo(0, 0);
  };

  const showNavbar = currentPage !== 'login' && currentPage !== 'globe';

  return (
    <div className="min-h-screen bg-gray-50">
      {showNavbar && <Navbar currentPage={currentPage} onNavigate={navigate} />}

      {currentPage === 'home' && <HomePage onNavigate={navigate} />}
      {currentPage === 'login' && <LoginPage onNavigate={navigate} />}
      {currentPage === 'modules' && <ModulesPage onNavigate={navigate} />}
      {currentPage === 'globe' && <GlobePage onNavigate={navigate} />}
      {currentPage === 'scanner' && <ScannerPage onNavigate={navigate} />}
      {currentPage === 'films' && <FilmsPage onNavigate={navigate} />}
      {currentPage === 'license' && <LicensePage onNavigate={navigate} />}
      {currentPage === 'school' && <SchoolPage onNavigate={navigate} />}
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
