export interface LearningModule {
  id: string;
  title: string;
  titleEn: string;
  description: string;
  icon: string;
  color: string;
  gradient: string;
  premium: boolean;
  lessons: Lesson[];
  category: 'literacy' | 'numeracy' | 'world' | 'creative' | 'science' | 'character';
}

export interface Lesson {
  id: string;
  title: string;
  content: string;
  type: 'text' | 'quiz' | 'interactive' | 'video';
  items?: QuizItem[];
}

export interface QuizItem {
  question: string;
  options: string[];
  correct: number;
  explanation?: string;
}

export const modules: LearningModule[] = [
  {
    id: 'math',
    title: 'Matematika',
    titleEn: 'Mathematics',
    description: 'Belajar angka, hitung, dan operasi dasar matematika dengan cara menyenangkan!',
    icon: '🔢',
    color: 'blue',
    gradient: 'from-blue-500 to-blue-700',
    premium: false,
    category: 'numeracy',
    lessons: [
      {
        id: 'math-1', title: 'Mengenal Angka 1-10', type: 'text',
        content: 'Mari belajar mengenal angka dari 1 sampai 10! Setiap angka memiliki bentuk dan nilai uniknya sendiri. 1️⃣ Satu - seperti tongkat berdiri tegak. 2️⃣ Dua - seperti angsa berenang. 3️⃣ Tiga - seperti kupu-kupu dari samping.'
      },
      {
        id: 'math-2', title: 'Penjumlahan Dasar', type: 'quiz',
        content: 'Latihan penjumlahan sederhana untuk anak-anak.',
        items: [
          { question: '2 + 3 = ?', options: ['4', '5', '6', '7'], correct: 1, explanation: '2 ditambah 3 sama dengan 5' },
          { question: '1 + 4 = ?', options: ['3', '4', '5', '6'], correct: 2, explanation: '1 ditambah 4 sama dengan 5' },
          { question: '3 + 3 = ?', options: ['5', '6', '7', '8'], correct: 1, explanation: '3 ditambah 3 sama dengan 6' },
          { question: '5 + 2 = ?', options: ['6', '7', '8', '9'], correct: 1, explanation: '5 ditambah 2 sama dengan 7' },
        ]
      },
      {
        id: 'math-3', title: 'Pengurangan Dasar', type: 'quiz',
        content: 'Belajar pengurangan sederhana.',
        items: [
          { question: '5 - 2 = ?', options: ['2', '3', '4', '1'], correct: 1 },
          { question: '8 - 3 = ?', options: ['4', '5', '6', '7'], correct: 1 },
          { question: '10 - 4 = ?', options: ['5', '6', '7', '8'], correct: 1 },
        ]
      }
    ]
  },
  {
    id: 'reading',
    title: 'Membaca',
    titleEn: 'Reading',
    description: 'Kenali huruf alfabet dan belajar membaca kata-kata pertamamu!',
    icon: '📖',
    color: 'green',
    gradient: 'from-green-500 to-green-700',
    premium: false,
    category: 'literacy',
    lessons: [
      {
        id: 'read-1', title: 'Huruf Vokal', type: 'text',
        content: 'Huruf vokal adalah A, I, U, E, O. Huruf-huruf ini sangat penting karena setiap kata memiliki huruf vokal! A seperti "Apel" 🍎, I seperti "Ikan" 🐟, U seperti "Ular" 🐍, E seperti "Elang" 🦅, O seperti "Orang" 🧑'
      },
      {
        id: 'read-2', title: 'Mengenal Suku Kata', type: 'quiz',
        content: 'Belajar memisahkan kata menjadi suku kata.',
        items: [
          { question: 'Berapa suku kata dalam "BUKU"?', options: ['1', '2', '3', '4'], correct: 1, explanation: 'BU-KU = 2 suku kata' },
          { question: 'Huruf vokal dalam kata "MAKAN"?', options: ['M, K, N', 'A, A', 'M, A', 'A, K'], correct: 1 },
        ]
      }
    ]
  },
  {
    id: 'coloring',
    title: 'Mewarnai',
    titleEn: 'Coloring',
    description: 'Ekspresikan kreativitasmu melalui warna-warna indah!',
    icon: '🎨',
    color: 'pink',
    gradient: 'from-pink-500 to-rose-600',
    premium: false,
    category: 'creative',
    lessons: [
      {
        id: 'color-1', title: 'Warna Primer', type: 'text',
        content: 'Warna primer adalah warna dasar yang tidak bisa dibuat dari campuran warna lain: 🔴 MERAH - warna api dan mawar, 🔵 BIRU - warna langit dan laut, 🟡 KUNING - warna matahari dan pisang. Dari tiga warna ini, kita bisa membuat semua warna lain!'
      },
      {
        id: 'color-2', title: 'Campuran Warna', type: 'quiz',
        content: 'Apa yang terjadi jika kita mencampur warna?',
        items: [
          { question: 'Merah + Biru = ?', options: ['Hijau', 'Ungu', 'Oranye', 'Coklat'], correct: 1 },
          { question: 'Merah + Kuning = ?', options: ['Ungu', 'Hijau', 'Oranye', 'Pink'], correct: 2 },
          { question: 'Biru + Kuning = ?', options: ['Hijau', 'Ungu', 'Oranye', 'Abu-abu'], correct: 0 },
        ]
      }
    ]
  },
  {
    id: 'world',
    title: 'Dunia Kita',
    titleEn: 'Our World',
    description: 'Jelajahi benua, negara, dan budaya dari seluruh dunia!',
    icon: '🌍',
    color: 'indigo',
    gradient: 'from-indigo-500 to-purple-700',
    premium: true,
    category: 'world',
    lessons: [
      {
        id: 'world-1', title: '7 Benua', type: 'text',
        content: 'Bumi kita memiliki 7 benua: 🌏 Asia - benua terbesar, 🌍 Afrika - benua terpanas, 🌎 Amerika Utara, 🌎 Amerika Selatan, 🌍 Eropa - benua kecil tapi padat, 🌏 Australia/Oseania, 🧊 Antartika - benua terdingin.'
      },
      {
        id: 'world-2', title: 'Negara-negara Asia', type: 'quiz',
        content: 'Kenali negara-negara di Asia!',
        items: [
          { question: 'Apa ibukota Indonesia?', options: ['Bandung', 'Surabaya', 'Jakarta', 'Medan'], correct: 2 },
          { question: 'Negara mana yang terkenal dengan Gunung Fuji?', options: ['China', 'Korea', 'Jepang', 'Thailand'], correct: 2 },
          { question: 'Tembok Besar ada di negara?', options: ['India', 'China', 'Mongolia', 'Rusia'], correct: 1 },
        ]
      }
    ]
  },
  {
    id: 'animals',
    title: 'Dunia Hewan',
    titleEn: 'Animals',
    description: 'Kenali berbagai hewan dari seluruh penjuru dunia!',
    icon: '🦁',
    color: 'amber',
    gradient: 'from-amber-500 to-orange-600',
    premium: false,
    category: 'science',
    lessons: [
      {
        id: 'animal-1', title: 'Hewan Mamalia', type: 'text',
        content: 'Mamalia adalah hewan yang menyusui anaknya. Contoh: 🦁 Singa - raja hutan, 🐘 Gajah - hewan darat terbesar, 🐬 Lumba-lumba - mamalia di laut, 🦇 Kelelawar - mamalia yang bisa terbang!'
      },
      {
        id: 'animal-2', title: 'Kuis Hewan', type: 'quiz',
        content: 'Seberapa banyak yang kamu tahu tentang hewan?',
        items: [
          { question: 'Hewan apa yang paling besar di dunia?', options: ['Gajah', 'Paus Biru', 'Jerapah', 'Dinosaurus'], correct: 1 },
          { question: 'Hewan apa yang punya leher paling panjang?', options: ['Ular', 'Angsa', 'Jerapah', 'Flamingo'], correct: 2 },
        ]
      }
    ]
  },
  {
    id: 'science',
    title: 'Sains',
    titleEn: 'Science',
    description: 'Eksplorasi sains dan alam semesta dengan eksperimen seru!',
    icon: '🔬',
    color: 'cyan',
    gradient: 'from-cyan-500 to-teal-600',
    premium: true,
    category: 'science',
    lessons: [
      {
        id: 'sci-1', title: 'Tata Surya', type: 'text',
        content: 'Tata Surya kita terdiri dari Matahari dan 8 planet: ☀️ Matahari, 1️⃣ Merkurius, 2️⃣ Venus, 3️⃣ Bumi 🌍, 4️⃣ Mars, 5️⃣ Jupiter, 6️⃣ Saturnus 🪐, 7️⃣ Uranus, 8️⃣ Neptunus'
      },
      {
        id: 'sci-2', title: 'Kuis Tata Surya', type: 'quiz',
        content: 'Test pengetahuan tentang tata surya!',
        items: [
          { question: 'Planet apa yang paling dekat dengan Matahari?', options: ['Venus', 'Bumi', 'Merkurius', 'Mars'], correct: 2 },
          { question: 'Planet apa yang memiliki cincin?', options: ['Jupiter', 'Saturnus', 'Neptunus', 'Mars'], correct: 1 },
        ]
      }
    ]
  },
  {
    id: 'moral',
    title: 'Nilai Moral',
    titleEn: 'Moral Values',
    description: 'Belajar tentang kejujuran, kebaikan, dan nilai-nilai kehidupan!',
    icon: '💖',
    color: 'rose',
    gradient: 'from-rose-500 to-red-600',
    premium: false,
    category: 'character',
    lessons: [
      {
        id: 'moral-1', title: 'Kejujuran', type: 'text',
        content: 'Kejujuran adalah sifat yang sangat penting. Orang yang jujur selalu berkata benar dan tidak berbohong. 🌟 Cerita: Ada seorang anak bernama Budi. Suatu hari ia memecahkan vas bunga. Meskipun takut, Budi berkata jujur kepada ibunya. Ibunya tidak marah, malah memuji kejujuran Budi!'
      },
      {
        id: 'moral-2', title: 'Kuis Nilai Moral', type: 'quiz',
        content: 'Apa yang akan kamu lakukan?',
        items: [
          { question: 'Temanmu jatuh di sekolah. Apa yang kamu lakukan?', options: ['Menertawakan', 'Membantu berdiri', 'Mengabaikan', 'Berlari pergi'], correct: 1 },
          { question: 'Kamu menemukan uang di lantai. Apa yang harus dilakukan?', options: ['Mengambilnya', 'Memberikan ke guru', 'Membuangnya', 'Menyembunyikan'], correct: 1 },
        ]
      }
    ]
  },
  {
    id: 'shapes',
    title: 'Bentuk & Pola',
    titleEn: 'Shapes & Patterns',
    description: 'Kenali bentuk geometri dan pola menarik di sekitar kita!',
    icon: '🔷',
    color: 'violet',
    gradient: 'from-violet-500 to-purple-600',
    premium: true,
    category: 'numeracy',
    lessons: [
      {
        id: 'shape-1', title: 'Bentuk Dasar', type: 'text',
        content: '⬛ Persegi - memiliki 4 sisi sama panjang, ▶️ Segitiga - memiliki 3 sisi, ⭕ Lingkaran - tidak memiliki sudut, ⬟ Segi Lima - memiliki 5 sisi, ⬡ Segi Enam - memiliki 6 sisi seperti sarang lebah!'
      },
      {
        id: 'shape-2', title: 'Kuis Bentuk', type: 'quiz',
        content: 'Kenali bentuk-bentuk ini!',
        items: [
          { question: 'Bentuk apa yang memiliki 3 sisi?', options: ['Persegi', 'Lingkaran', 'Segitiga', 'Segi Lima'], correct: 2 },
          { question: 'Bentuk apa yang tidak memiliki sudut?', options: ['Persegi', 'Segitiga', 'Belah Ketupat', 'Lingkaran'], correct: 3 },
        ]
      }
    ]
  },
  {
    id: 'professions',
    title: 'Profesi',
    titleEn: 'Professions',
    description: 'Kenali berbagai profesi dan cita-citamu di masa depan!',
    icon: '👨‍⚕️',
    color: 'teal',
    gradient: 'from-teal-500 to-emerald-600',
    premium: true,
    category: 'world',
    lessons: [
      {
        id: 'prof-1', title: 'Profesi Hebat', type: 'text',
        content: '👨‍⚕️ Dokter - menolong orang sakit, 👩‍🏫 Guru - mengajar dengan sabar, 👨‍🚒 Pemadam Kebakaran - berani memadamkan api, 👩‍🚀 Astronaut - menjelajahi luar angkasa, 👨‍🍳 Koki - memasak makanan lezat, 👩‍💻 Programmer - membuat aplikasi!'
      },
      {
        id: 'prof-2', title: 'Kuis Profesi', type: 'quiz',
        content: 'Cocokkan profesi dengan pekerjaannya!',
        items: [
          { question: 'Siapa yang bekerja di rumah sakit?', options: ['Guru', 'Dokter', 'Polisi', 'Pilot'], correct: 1 },
          { question: 'Siapa yang menerbangkan pesawat?', options: ['Masinis', 'Nahkoda', 'Pilot', 'Astronaut'], correct: 2 },
        ]
      }
    ]
  }
];

export const countries = [
  { name: 'Indonesia', lat: -2.5, lng: 118, capital: 'Jakarta', population: '270 juta', language: 'Bahasa Indonesia', flag: '🇮🇩', fact: 'Negara kepulauan terbesar di dunia dengan 17.000+ pulau' },
  { name: 'Jepang', lat: 36, lng: 138, capital: 'Tokyo', population: '126 juta', language: 'Jepang', flag: '🇯🇵', fact: 'Dikenal sebagai Negeri Matahari Terbit' },
  { name: 'Amerika Serikat', lat: 38, lng: -97, capital: 'Washington D.C.', population: '331 juta', language: 'Inggris', flag: '🇺🇸', fact: 'Memiliki 50 negara bagian' },
  { name: 'Brasil', lat: -14, lng: -51, capital: 'Brasilia', population: '212 juta', language: 'Portugis', flag: '🇧🇷', fact: 'Memiliki hutan hujan Amazon terbesar' },
  { name: 'Mesir', lat: 26, lng: 30, capital: 'Kairo', population: '100 juta', language: 'Arab', flag: '🇪🇬', fact: 'Rumah bagi Piramida Giza yang terkenal' },
  { name: 'India', lat: 20, lng: 78, capital: 'New Delhi', population: '1.4 miliar', language: 'Hindi, Inggris', flag: '🇮🇳', fact: 'Negara dengan populasi terbanyak ke-2' },
  { name: 'Australia', lat: -25, lng: 133, capital: 'Canberra', population: '25 juta', language: 'Inggris', flag: '🇦🇺', fact: 'Benua terkecil, rumah kanguru dan koala' },
  { name: 'Prancis', lat: 46, lng: 2, capital: 'Paris', population: '67 juta', language: 'Prancis', flag: '🇫🇷', fact: 'Memiliki Menara Eiffel yang ikonik' },
  { name: 'China', lat: 35, lng: 105, capital: 'Beijing', population: '1.4 miliar', language: 'Mandarin', flag: '🇨🇳', fact: 'Memiliki Tembok Besar sepanjang 21.000 km' },
  { name: 'Kenya', lat: 0, lng: 38, capital: 'Nairobi', population: '53 juta', language: 'Swahili, Inggris', flag: '🇰🇪', fact: 'Terkenal dengan safari dan hewan liar' },
  { name: 'Korea Selatan', lat: 36, lng: 128, capital: 'Seoul', population: '52 juta', language: 'Korea', flag: '🇰🇷', fact: 'Negara dengan internet tercepat di dunia' },
  { name: 'Meksiko', lat: 23, lng: -102, capital: 'Mexico City', population: '128 juta', language: 'Spanyol', flag: '🇲🇽', fact: 'Peradaban Maya dan Aztec berasal dari sini' },
];

export const filmScript = {
  title: 'Petualangan Aksa & Globe Ajaib',
  duration: '5 menit',
  synopsis: 'Aksa, seorang anak yang penasaran tentang dunia, menemukan globe ajaib di perpustakaan kakeknya. Globe itu bisa membawanya menjelajahi berbagai negara!',
  scenes: [
    { time: '0:00-0:30', title: 'Pembukaan', narration: 'Di sebuah kota kecil, hiduplah seorang anak bernama Aksa. Ia sangat suka membaca buku tentang negara-negara di dunia. Suatu hari, saat bermain di rumah kakek...' },
    { time: '0:30-1:00', title: 'Penemuan Globe', narration: 'Aksa menemukan sebuah globe tua yang berdebu di loteng. Saat ia memutarnya, globe itu mulai bersinar! "Wah, apa ini?" kata Aksa dengan takjub.' },
    { time: '1:00-2:00', title: 'Perjalanan ke Indonesia', narration: 'WHOOSH! Aksa terbang ke Indonesia! Ia melihat Candi Borobudur, bermain di pantai Bali, dan mencicipi nasi goreng yang lezat. "Indonesia luar biasa!" serunya.' },
    { time: '2:00-3:00', title: 'Menjelajahi Jepang', narration: 'Globe berputar lagi! Kini Aksa di Jepang, melihat Gunung Fuji yang megah, belajar origami, dan makan sushi. Ia belajar memberi salam: "Konnichiwa!"' },
    { time: '3:00-4:00', title: 'Petualangan di Mesir', narration: 'Destinasi selanjutnya: Mesir! Aksa takjub melihat Piramida dan Sphinx. Ia belajar tentang firaun dan hieroglif kuno. "Sejarah sangat menarik!" katanya.' },
    { time: '4:00-4:30', title: 'Kembali ke Rumah', narration: 'Globe membawa Aksa pulang. Ia memeluk kakeknya dan bercerita tentang petualangannya. "Dunia ini penuh keajaiban, Kek!" kata Aksa bahagia.' },
    { time: '4:30-5:00', title: 'Penutup', narration: 'Aksa berjanji akan terus belajar tentang dunia. Karena setiap negara punya keunikan dan keindahannya sendiri. Dan globe ajaib itu... selalu menunggu petualangan berikutnya! 🌍✨' },
  ]
};
