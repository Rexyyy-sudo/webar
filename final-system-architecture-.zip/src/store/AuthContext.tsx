import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

export type UserRole = 'guest' | 'basic' | 'premium';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  schoolId?: string;
  activatedLicense?: string;
  createdAt: string;
}

export interface School {
  id: string;
  name: string;
  plan: string;
  maxUsers: number;
  activeUntil: string;
}

interface AuthContextType {
  user: User | null;
  school: School | null;
  isLoggedIn: boolean;
  isPremium: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  activateLicense: (code: string) => Promise<{ success: boolean; message: string }>;
  activateSchool: (schoolName: string, plan: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const PREMIUM_CODES = ['EDUCARD-PREMIUM-2024', 'AKSA-GLOBE-VIP', 'SCHOOL-LICENSE-001', 'DEMO-PREMIUM-123', 'EDU2024PRO'];

const STORAGE_KEY = 'educard_user';
const SCHOOL_KEY = 'educard_school';
const LICENSES_KEY = 'educard_licenses';

function loadUser(): User | null {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : null;
  } catch { return null; }
}

function loadSchool(): School | null {
  try {
    const data = localStorage.getItem(SCHOOL_KEY);
    return data ? JSON.parse(data) : null;
  } catch { return null; }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(loadUser);
  const [school, setSchool] = useState<School | null>(loadSchool);

  const saveUser = (u: User | null) => {
    setUser(u);
    if (u) localStorage.setItem(STORAGE_KEY, JSON.stringify(u));
    else localStorage.removeItem(STORAGE_KEY);
  };

  const login = useCallback(async (email: string, _password: string): Promise<boolean> => {
    // Simulated backend login
    const existingUsers = JSON.parse(localStorage.getItem('educard_users') || '[]');
    const found = existingUsers.find((u: User) => u.email === email);
    if (found) {
      saveUser(found);
      return true;
    }
    // Auto-create for demo
    const newUser: User = {
      id: crypto.randomUUID(),
      name: email.split('@')[0],
      email,
      role: 'basic',
      createdAt: new Date().toISOString()
    };
    existingUsers.push(newUser);
    localStorage.setItem('educard_users', JSON.stringify(existingUsers));
    saveUser(newUser);
    return true;
  }, []);

  const register = useCallback(async (name: string, email: string, _password: string): Promise<boolean> => {
    const newUser: User = {
      id: crypto.randomUUID(),
      name,
      email,
      role: 'basic',
      createdAt: new Date().toISOString()
    };
    const existingUsers = JSON.parse(localStorage.getItem('educard_users') || '[]');
    existingUsers.push(newUser);
    localStorage.setItem('educard_users', JSON.stringify(existingUsers));
    saveUser(newUser);
    return true;
  }, []);

  const logout = useCallback(() => {
    saveUser(null);
  }, []);

  const activateLicense = useCallback(async (code: string): Promise<{ success: boolean; message: string }> => {
    const usedLicenses: string[] = JSON.parse(localStorage.getItem(LICENSES_KEY) || '[]');
    
    if (usedLicenses.includes(code)) {
      return { success: false, message: 'Kode lisensi sudah digunakan!' };
    }
    
    if (!PREMIUM_CODES.includes(code.toUpperCase())) {
      return { success: false, message: 'Kode lisensi tidak valid!' };
    }

    if (!user) return { success: false, message: 'Silakan login terlebih dahulu!' };

    usedLicenses.push(code);
    localStorage.setItem(LICENSES_KEY, JSON.stringify(usedLicenses));

    const updatedUser: User = { ...user, role: 'premium', activatedLicense: code };
    const existingUsers = JSON.parse(localStorage.getItem('educard_users') || '[]');
    const idx = existingUsers.findIndex((u: User) => u.id === user.id);
    if (idx >= 0) existingUsers[idx] = updatedUser;
    localStorage.setItem('educard_users', JSON.stringify(existingUsers));
    saveUser(updatedUser);

    return { success: true, message: 'Selamat! Akun Anda telah diupgrade ke Premium! 🎉' };
  }, [user]);

  const activateSchool = useCallback((schoolName: string, plan: string) => {
    const newSchool: School = {
      id: crypto.randomUUID(),
      name: schoolName,
      plan,
      maxUsers: plan === 'enterprise' ? 500 : plan === 'pro' ? 100 : 30,
      activeUntil: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
    };
    setSchool(newSchool);
    localStorage.setItem(SCHOOL_KEY, JSON.stringify(newSchool));
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      school,
      isLoggedIn: !!user,
      isPremium: user?.role === 'premium',
      login,
      register,
      logout,
      activateLicense,
      activateSchool
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
